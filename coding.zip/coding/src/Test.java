
import java.util.Scanner;

public class Test {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("How much money is in your bank account?");
        double amount = input.nextDouble();
        Testing harrysBank = new Testing(amount);

        boolean questions = true;

        while (questions) {
            System.out.println(" ");
            System.out.println("What would you like to do? (Deposit/Withdraw/Balance/Get A Loan/Loan Debt/Pay Off Loan) [EXIT to end]");
            String answer = input.nextLine();


            if (answer.equalsIgnoreCase("deposit")) {
                System.out.println(" ");
                System.out.println("How much money would you like to deposit?");
                double deposit = input.nextDouble();
                harrysBank.deposit(deposit);
                System.out.println("You've successfully deposited " + deposit + "$");
                System.out.println(" ");
            }
            if (answer.equalsIgnoreCase("withdraw")) {
                System.out.println(" ");
                System.out.println("How much money would you like to withdraw?");
                double withdraw = input.nextDouble();
                harrysBank.withdraw(withdraw);
                System.out.println("You've successfully withdrawed " + withdraw + "$");
                System.out.println(" ");

            }
            if (answer.equalsIgnoreCase("balance")) {
                System.out.println(" ");
                System.out.println("Your balance is " + harrysBank.getBalance() + "$");
                System.out.println(" ");

            }
            if (answer.equalsIgnoreCase("get a loan")) {
                System.out.println(" ");
                System.out.println("How much money would you like to get a loan of?");
                double loan = input.nextDouble();
                harrysBank.getLoan(loan);
                System.out.println("You've successfully got a loan of " + loan + "$");
                System.out.println("Your balance after the loan is " + harrysBank.getBalance() + "$");
                System.out.println(" ");
            }
            if (answer.equalsIgnoreCase("loan debt")) {
                System.out.println(" ");
                System.out.println("You borrowed " + harrysBank.getLoanAmount() + "$" + " in loans.");
                System.out.println("The amount of money you owe back to the bank from your loan is " + harrysBank.getLoanPayment() + "$");
                System.out.println(" ");
            }
            if (answer.equalsIgnoreCase("pay off loan")){
                System.out.println(" ");
                System.out.println("The amount of money you owe back to the bank from your loan is " + harrysBank.getLoanPayment() + "$");
                System.out.println("How much money would you like to pay off?");
                System.out.println(" ");
                double pay = input.nextDouble();
                harrysBank.payLoan(pay);
            }
            if (answer.equalsIgnoreCase("exit")) {
                questions = false;
            }
        }
        System.out.println("Program end.");
    }
    }

