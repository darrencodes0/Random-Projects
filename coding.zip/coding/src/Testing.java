public class Testing {
    double balance;
    double loan;
    double loanPay;

    public Testing(double money) {
        balance = money;
    }

    public void deposit(double amount) {
        balance = balance + amount;
    }

    public void withdraw(double amount) {
        balance = balance - amount;
    }

    public void getLoan(double loanAmount) {
        balance = loanAmount + balance;
        loan = loanAmount;
        loanPay = loanAmount * 1.10;
    }

    public void payLoan(double amountInserted) {
        if (!(amountInserted < 0)) {
            if (amountInserted > balance) {
                System.out.println("");
                System.out.println("You don't have enough money to pay off your loan");
                System.out.println("");
            } else if (amountInserted < balance) {
                balance = balance - amountInserted;
                loanPay = loanPay - amountInserted;
                System.out.println("");
                System.out.println("You have payed off " + amountInserted + "$ from your loan.");
                System.out.println("");
            }
        } else {
            System.out.println("Invalid input.");
        }
    }

        public double getBalance() {
            return balance;
        }
        public double getLoanAmount() {
            return loan;
        }
        public double getLoanPayment() {
            if (loanPay > 0) {
                return loanPay;
            } else {
                return 0;
            }
        }
    }

